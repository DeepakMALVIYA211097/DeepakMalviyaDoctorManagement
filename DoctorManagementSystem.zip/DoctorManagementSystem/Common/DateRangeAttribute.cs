﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace DoctorManagementSystem.Common
{
    public class DateRangeAttribute : ValidationAttribute
    {
        protected override ValidationResult IsValid(object value,ValidationContext validationContext)
        {
           
            if (value != null)
            {
                DateTime propValue = Convert.ToDateTime(value);

                if (propValue <= DateTime.Now.AddDays(60) && propValue >= DateTime.Now)
                {
                    return ValidationResult.Success;
                }
            }
            return new ValidationResult("Date should be between current date and two upcoming months from now.");
        }
    }
}
