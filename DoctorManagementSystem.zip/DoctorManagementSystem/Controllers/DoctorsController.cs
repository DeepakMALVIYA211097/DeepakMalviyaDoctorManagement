﻿using DoctorManagementSystem.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace DoctorManagementSystem.Controllers
{
    public class DoctorsController : Microsoft.AspNetCore.Mvc.Controller
    {
        private DoctorManagementSystemDbContext doctorManagementDb;//dependency injection

        public DoctorsController(DoctorManagementSystemDbContext doctorManagementDb)
        {
            this.doctorManagementDb = doctorManagementDb;
        }

        public async Task<IActionResult> AppointmenIndex()
        {
            return View(await doctorManagementDb.Appointments.ToListAsync());
        }

        public async Task<IActionResult> Index()
        {
            return View(await doctorManagementDb.Doctors.ToListAsync());
        }
        [Microsoft.AspNetCore.Mvc.HttpGet]
        public async Task<IActionResult> Create()
        {
           
                CityViewModel cityViewModel = new CityViewModel();
                cityViewModel.Cities = await doctorManagementDb.Cities.ToListAsync();
                cityViewModel.Doctor = new Doctor();
            return View(cityViewModel);
        }
        [Microsoft.AspNetCore.Mvc.HttpPost]
        [Microsoft.AspNetCore.Mvc.ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Doctor doctor)
        {
            if (ModelState.IsValid)
            {
                await doctorManagementDb.Doctors.AddAsync(doctor);
                await doctorManagementDb.SaveChangesAsync();
            }
          return View("Index", await doctorManagementDb.Doctors.ToListAsync());
        }
        [Microsoft.AspNetCore.Mvc.HttpGet]
        public IActionResult Edit(int id)
        {

            var doctor = doctorManagementDb.Doctors.Where(p => p.Id == id).FirstOrDefault();
            var c = doctorManagementDb.Cities.ToList();
            ViewBag.CityList = new Microsoft.AspNetCore.Mvc.Rendering.SelectList(c, "Id", "Name");

            return View(doctor);

        }
        [Microsoft.AspNetCore.Mvc.HttpPost]
        [Microsoft.AspNetCore.Mvc.ValidateAntiForgeryToken]
        public IActionResult Edit(Doctor doctor)
        {
            if (ModelState.IsValid)
            {
                doctorManagementDb.Doctors.Update(doctor);
                doctorManagementDb.SaveChanges();
            }
                return View("Index", doctorManagementDb.Doctors.ToList());
        }
        [Microsoft.AspNetCore.Mvc.HttpGet]
        public IActionResult Delete(int id)
        {

            var doctor = doctorManagementDb.Doctors.Where(p => p.Id == id).FirstOrDefault();
            doctor.City = doctorManagementDb.Cities.Where(m => m.Id == doctor.CityId).FirstOrDefault();
            return View(doctor);
        }
        [Microsoft.AspNetCore.Mvc.HttpPost]
        public IActionResult Delete(Doctor doctor)
        {
            Doctor d = doctorManagementDb.Doctors.Find(doctor.Id);
            doctorManagementDb.Remove(d);
            doctorManagementDb.SaveChanges();
            return View("Index", doctorManagementDb.Doctors.ToList());
        }

        public IActionResult Details(int id)
        {
            var doctor = doctorManagementDb.Doctors.Where(p => p.Id == id).FirstOrDefault();
            doctor.City = doctorManagementDb.Cities.Where(m => m.Id == doctor.CityId).FirstOrDefault();
            return View(doctor);
        }

        [Microsoft.AspNetCore.Mvc.HttpGet]
        public IActionResult AppointmentCreate()
        { 
            DoctorViewModel doctorViewModel = new DoctorViewModel();
            doctorViewModel.Doctors = doctorManagementDb.Doctors.ToList();
            doctorViewModel.Appointment = new Appointment();

            return View(doctorViewModel);
        }
        [Microsoft.AspNetCore.Mvc.HttpPost]
        [Microsoft.AspNetCore.Mvc.ValidateAntiForgeryToken]
        public IActionResult AppointmentCreate(Appointment appointment)
        {
            var appointmentBooked = doctorManagementDb.Appointments.Where(a => a.AppointmentDate == appointment.AppointmentDate && a.AppointmentTime == appointment.AppointmentTime && a.DoctorId == appointment.DoctorId).FirstOrDefault();
           if(appointmentBooked!=null)
           {
                ModelState.AddModelError(nameof(appointment.AppointmentTime), "Sorry this slot already booked, please select another slot");
           }

            if (ModelState.IsValid)
            {
                doctorManagementDb.Appointments.Add(appointment);
                doctorManagementDb.SaveChanges();
                ViewBag.Message = "Appointment Scheduled! Please be there on time";
            }
            else
            {
                if(appointmentBooked!=null)
                    TempData["msg"] = "Sorry this slot already booked, please select another slot";
                else
                TempData["msg"] = "Appointment Schedule Failed! Please select the date within 2 months from now.";
                return RedirectToAction("AppointmentCreate");
            }
            return View("AppointmenIndex", doctorManagementDb.Appointments.ToList());
        }
    }
}
