﻿using DoctorManagementSystem.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DoctorManagementSystem.Controllers
{
    public class AccountController : Controller
    {
        private DoctorManagementSystemDbContext doctorManagementSystemDbContext;
        public AccountController(DoctorManagementSystemDbContext doctorManagementSystemDbContext)
        {
            this.doctorManagementSystemDbContext = doctorManagementSystemDbContext;
        }
        [HttpGet]
        public IActionResult SignUp()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> SignUp(ApplicationUser applicationUser)
        {
            doctorManagementSystemDbContext.Users.Add(applicationUser);
            await doctorManagementSystemDbContext.SaveChangesAsync();
            ViewBag.Message = "Signup successful!";
            return View();
        }

        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Login(ApplicationUser applicationUser)
        {
            var user = doctorManagementSystemDbContext
                .Users.Where(u => u.Email == applicationUser.Email && u.Password == applicationUser.Password)
                .FirstOrDefault();
            if (user == null)
            {
                ViewBag.Message = "Invalid username/password!";
                return View();
            }

            HttpContext.Session.SetString("Email", user.Email);
            return RedirectToAction("Index", "Doctors");
        }


        [HttpGet]
        public IActionResult Logout()
        {
            HttpContext.Session.Remove("Email");
            return View("Login");
        }
    }
}
