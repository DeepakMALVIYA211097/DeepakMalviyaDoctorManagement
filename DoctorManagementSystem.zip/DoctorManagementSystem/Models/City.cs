﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace DoctorManagementSystem.Models
{
    public class City
    {
        [Key]
        public int Id { get; set; }

        [Required(ErrorMessage = "Please provide city name")]
        [StringLength(maximumLength: 50)]
        public string Name { get; set; }
        public virtual List<Doctor> Doctors { get; set; }
    }
}
