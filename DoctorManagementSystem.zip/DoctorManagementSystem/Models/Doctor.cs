﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
using static DoctorManagementSystem.Models.CityViewModel;

namespace DoctorManagementSystem.Models
{
    public class Doctor
    {
        [Key]
        public int Id { get; set; }

        [Required(ErrorMessage = "Please provide doctor name")]
        [StringLength(maximumLength: 255)]
        public string Name { get; set; }
        [Required(ErrorMessage = "Please provide mobile")]
        public string Mobile { get; set; }

        [Required(ErrorMessage = "Please provide date of birth")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString= "{0:dd-MM-yy}",ApplyFormatInEditMode = true)]
        public DateTime DateOfBirth { get; set; }

        [Required(ErrorMessage = "Please Select Speciality")]
        public Speciality speciality { get; set; }

        [Required(ErrorMessage = "Please Experience")]
        [Range(minimum: 0, maximum: 50)]
        public int Experience { get; set; }

        [Required(ErrorMessage = "Please Consultation")]
        [Display(Name = "Virtual Consultation Supported?")]
        public bool VirtualConsultation { get; set; }

        [Required(ErrorMessage="Please select city")]
        [Display(Name = "City")]
        public int CityId { get; set; }

        public City City { get; set; }

        public enum Speciality
        {
            Cardiologist,
            Gynacologist,
            Physician,
            Neurologist,
            Radiologist,
        }

    }
}
