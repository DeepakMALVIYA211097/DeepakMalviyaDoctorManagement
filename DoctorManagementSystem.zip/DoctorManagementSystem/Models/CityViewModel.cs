﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DoctorManagementSystem.Models
{
    public class CityViewModel
    {
        public List<City> Cities { get; set; }
        public Doctor Doctor { get; set; }

       
    }
}
