﻿using DoctorManagementSystem.Common;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace DoctorManagementSystem.Models
{ 
    public class Appointment
    {
        [Key]
        public int Id { get; set; }

        [Required(ErrorMessage = "Please provide Patient Name")]
        [MaxLength(50)]
        public string PatientName { get; set; }

        [Required(ErrorMessage = "Please provide Patient Mobile")]
        [MaxLength(10)]
        public string PatientMobile { get; set; }

        [Required(ErrorMessage = "Please Select Gender")]
        public string PatientGender { get; set; }

        [Required(ErrorMessage = "Please Provide Age")]
        [Range(minimum: 0, maximum: 100)]
        public int PatientAge { get; set; }

        [Required(ErrorMessage = "Please Provide Valid AppointmentDate")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:ddMM-yy}", ApplyFormatInEditMode = true)]
        [DateRange]
        public DateTime AppointmentDate { get; set; }

        [Required(ErrorMessage = "Please Provide AppointmentTime")]
        public string AppointmentTime { get; set; }

        [Required(ErrorMessage = "Please provide Doctor")]
        public int DoctorId { get; set; }
        public Doctor Doctor { get; set; }
    }
}
